var config = window.config = {};

var stompClient = {
		client : null,
		socket : null,
		connect : function() {
			this.socket = new SockJS('/cosmos/websocket');
			this.client = Stomp.over(this.socket);
			//            this.client.debug = null;
			this.client.connect({}, function(frame) {
				stompClient.client.subscribe('/topic/chatbot', function(events) {
					stompClient.consume(events);
				});

			});
		},
		consume : function(raw) {
			//console.log("Chart DAta   "+raw);
			showChart(JSON.parse(raw.body));

		},
		close : function() {

			if (this.client != null && this.client != undefined) {
				this.client.unsubscribe('/topic/chatbot');
				//	this.client.unsubscribe('/topic/count');
				this.client.disconnect();
				this.client = null;
			}
			closeChart(); // closing chart window
		}
	};

// Config reference element
var $ref = $("#ref");

// Configure responsive bootstrap toolkit
config.ResponsiveBootstrapToolkitVisibilityDivs = {
	'xs' : $('<div class="device-xs 				  hidden-sm-up"></div>'),
	'sm' : $('<div class="device-sm hidden-xs-down hidden-md-up"></div>'),
	'md' : $('<div class="device-md hidden-sm-down hidden-lg-up"></div>'),
	'lg' : $('<div class="device-lg hidden-md-down hidden-xl-up"></div>'),
	'xl' : $('<div class="device-xl hidden-lg-down			  "></div>'),
};

ResponsiveBootstrapToolkit.use('Custom', config.ResponsiveBootstrapToolkitVisibilityDivs);

//validation configuration
config.validations = {
	debug : true,
	errorClass : 'has-error',
	validClass : 'success',
	errorElement : "span",

	// add error class
	highlight : function(element, errorClass, validClass) {
		$(element).parents("div.form-group")
			.addClass(errorClass)
			.removeClass(validClass);
	},

	// add error class
	unhighlight : function(element, errorClass, validClass) {
		$(element).parents(".has-error")
			.removeClass(errorClass)
			.addClass(validClass);
	},

	// submit handler
	submitHandler : function(form) {
		form.submit();
	}
}

//delay time configuration
config.delayTime = 50;

// chart configurations
config.chart = {};

config.chart.colorPrimary = tinycolor($ref.find(".chart .color-primary").css("color"));
config.chart.colorSecondary = tinycolor($ref.find(".chart .color-secondary").css("color"));
/***********************************************
*        Animation Settings
***********************************************/
function animate(options) {
	var animationName = "animated " + options.name;
	var animationEnd = "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
	$(options.selector)
		.addClass(animationName)
		.one(animationEnd,
			function() {
				$(this).removeClass(animationName);
			}
	);
}

$(function() {
	var $itemActions = $(".item-actions-dropdown");

	$(document).on('click', function(e) {
		if (!$(e.target).closest('.item-actions-dropdown').length) {
			$itemActions.removeClass('active');
		}
	});

	$('.item-actions-toggle-btn').on('click', function(e) {
		e.preventDefault();

		var $thisActionList = $(this).closest('.item-actions-dropdown');

		$itemActions.not($thisActionList).removeClass('active');

		$thisActionList.toggleClass('active');
	});
});

/***********************************************
*        NProgress Settings
***********************************************/
var npSettings = {
	easing : 'ease',
	speed : 500
}

NProgress.configure(npSettings);
$(function() {
	setSameHeights();

	var resizeTimer;

	$(window).resize(function() {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(setSameHeights, 150);
	});
});


function setSameHeights($container) {
	$container = $container || $('.sameheight-container');

	var viewport = ResponsiveBootstrapToolkit.current();

	$container.each(function() {

		var $items = $(this).find(".sameheight-item");

		// Get max height of items in container
		var maxHeight = 0;

		$items.each(function() {
			$(this).css({
				height : 'auto'
			});
			maxHeight = Math.max(maxHeight, $(this).innerHeight());
		});


		// Set heights of items
		$items.each(function() {
			// Ignored viewports for item
			var excludedStr = $(this).data('exclude') || '';
			var excluded = excludedStr.split(',');

			// Set height of element if it's not excluded on 
			if (excluded.indexOf(viewport) === -1) {
				$(this).innerHeight(maxHeight);
			}
		});
	});
}

$(document).on('click', '.panel-heading span.icon_minim', function(e) {
	var $this = $(this);
	if (!$this.hasClass('panel-collapsed')) {
		$this.parents('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.removeClass('glyphicon-minus').addClass('glyphicon-plus');
	} else {
		$this.parents('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.removeClass('glyphicon-plus').addClass('glyphicon-minus');
	}
});
$(document).on('focus', '.panel-footer input.chat_input', function(e) {
	var $this = $(this);
	if ($('#minim_chat_window').hasClass('panel-collapsed')) {
		$this.parents('.panel').find('.panel-body').slideDown();
		$('#minim_chat_window').removeClass('panel-collapsed');
		$('#minim_chat_window').removeClass('glyphicon-plus').addClass('glyphicon-minus');
	}
});
$(document).on('click', '#new_chat', function(e) {
	var size = $(".chat-window:last-child").css("margin-left");
	size_total = parseInt(size) + 400;
	alert(size_total);
	var clone = $("#chat_window_1").clone().appendTo(".container");
	clone.css("margin-left", size_total);
});
$(document).on('click', '.icon_close', function(e) {
	//$(this).parent().parent().parent().parent().remove();
	$("#chat_window_1").remove();
});

//SignupForm validation
$(function() {
	if (!$('#signup-form').length) {
		return false;
	}

	var signupValidationSettings = {
		rules : {
			firstname : {
				required : true,
			},
			lastname : {
				required : true,
			},
			email : {
				required : true,
				email : true
			},
			password : {
				required : true,
				minlength : 8
			},
			retype_password : {
				required : true,
				minlength : 8,
				equalTo : "#password"
			},
			agree : {
				required : true,
			}
		},
		groups : {
			name : "firstname lastname",
			pass : "password retype_password",
		},
		errorPlacement : function(error, element) {
			if (
				element.attr("name") == "firstname" ||
				element.attr("name") == "lastname"
			) {
				error.insertAfter($("#lastname").closest('.row'));
				element.parents("div.form-group")
					.addClass('has-error');
			} else if (
				element.attr("name") == "password" ||
				element.attr("name") == "retype_password"
			) {
				error.insertAfter($("#retype_password").closest('.row'));
				element.parents("div.form-group")
					.addClass('has-error');
			} else if (element.attr("name") == "agree") {
				error.insertAfter("#agree-text");
			} else {
				error.insertAfter(element);
			}
		},
		messages : {
			firstname : "Please enter firstname and lastname",
			lastname : "Please enter firstname and lastname",
			email : {
				required : "Please enter email",
				email : "Please enter a valid email address"
			},
			password : {
				required : "Please enter password fields.",
				minlength : "Passwords should be at least 8 characters."
			},
			retype_password : {
				required : "Please enter password fields.",
				minlength : "Passwords should be at least 8 characters."
			},
			agree : "Please accept our policy"
		},
		invalidHandler : function() {
			animate({
				name : 'shake',
				selector : '.auth-container > .card'
			});
		}
	}

	$.extend(signupValidationSettings, config.validations);

	$('#signup-form').validate(signupValidationSettings);
});
//LoginForm validation
$(function() {
	if (!$('#login-form').length) {
		return false;
	}

	var loginValidationSettings = {
		rules : {
			username : {
				required : true,
				email : true
			},
			password : "required",
			agree : "required"
		},
		messages : {
			username : {
				required : "Please enter username",
				email : "Please enter a valid email address"
			},
			password : "Please enter password",
			agree : "Please accept our policy"
		},
		invalidHandler : function() {
			animate({
				name : 'shake',
				selector : '.auth-container > .card'
			});
		}
	}

	$.extend(loginValidationSettings, config.validations);

	$('#login-form').validate(loginValidationSettings);
})
$(function() {

	$('#sidebar-menu, #customize-menu').metisMenu({
		activeClass : 'open'
	});


	$('#sidebar-collapse-btn').on('click', function(event) {
		event.preventDefault();

		$("#app").toggleClass("sidebar-open");
	});

	$("#sidebar-overlay").on('click', function() {
		$("#app").removeClass("sidebar-open");
	});

});
$(function() {

	var $dashboardSalesMap = $('#dashboard-sales-map');

	if (!$dashboardSalesMap.length) {
		return false;
	}

	function drawSalesMap() {
		$dashboardSalesMap.empty();

		var color = config.chart.colorPrimary.toHexString();
		var darkColor = tinycolor(config.chart.colorPrimary.toString()).darken(40).toHexString();
		var selectedColor = tinycolor(config.chart.colorPrimary.toString()).darken(10).toHexString();

		var sales_data = {
			us : 2000,
			ru : 2000,
			gb : 10000,
			fr : 10000,
			de : 10000,
			cn : 10000,
			in : 10000,
			sa : 10000,
			ca : 10000,
			br : 5000,
			au : 5000
		};

		$dashboardSalesMap.vectorMap({
			map : 'world_en',
			backgroundColor : 'transparent',
			color : '#E5E3E5',
			hoverOpacity : 0.7,
			selectedColor : selectedColor,
			enableZoom : true,
			showTooltip : true,
			values : sales_data,
			scaleColors : [ color, darkColor ],
			normalizeFunction : 'linear'
		});
	}

	drawSalesMap();

	$(document).on("themechange", function() {
		drawSalesMap();
	});
});
// $(function() {

// 	$('.actions-list > li').on('click', '.check', function(e){
// 		e.preventDefault();

// 		$(this).parents('.tasks-item')
// 		.find('.checkbox')
// 		.prop("checked",  true);

// 		removeActionList();
// 	});

// });


$(function() {
	$('.hider').click(function() {
		return $(this).parent('.message').removeClass('blur');
	});
}.call(this));
$(function() {

	if (!$('#dashboard-downloads-chart').length) {
		return false;
	}

	drawDownloadsChart();

	var item = 'downloads';

	$(document).on("themechange", function() {
		switchHistoryCharts(item);
	});

	function switchHistoryCharts(item) {
		var chartSelector = "#dashboard-" + item + "-chart";

		if ($(chartSelector).has('svg').length) {
			$(chartSelector).empty();
		}

		switch (item) {
		case 'downloads':
			drawDownloadsChart();
			break;
		}
	}


	function drawDownloadsChart() {
		/*var dataDownloads = [
			{
				year : 'JAN',
				downloads : 1300
			},
			{
				year : 'FEB',
				downloads : 1526
			},
			{
				year : 'MAR',
				downloads : 2000
			},
			{
				year : 'APR',
				downloads : 1800
			},
			{
				year : 'MAY',
				downloads : 1650
			},
			{
				year : 'JUN',
				downloads : 620
			},
			{
				year : 'JUL',
				downloads : 1000
			},
			{
				year : 'AUG',
				downloads : 1896
			},
			{
				year : 'SEP',
				downloads : 850
			},
			{
				year : 'OCT',
				downloads : 1500
			}
		];


		Morris.Bar({
			element : 'dashboard-downloads-chart',
			data : dataDownloads,
			xkey : 'year',
			ykeys : [ 'downloads' ],
			labels : [ 'Downloads' ],
			hideHover : 'auto',
			resize : true,
			barColors : [
				config.chart.colorPrimary.toString(),
				tinycolor(config.chart.colorPrimary.toString()).darken(10).toString()
			],
		});*/
	}
});




$(function() {


	function drawDashboardItemsListSparklines() {
		$(".dashboard-page .items .sparkline").each(function() {
			var type = $(this).data('type');

			// There is predefined data
			if ($(this).data('data')) {
				var data = $(this).data('data').split(',').map(function(item) {
					if (item.indexOf(":") > 0) {
						return item.split(":");
					} else {
						return item;
					}
				});
			}
			// Generate random data
			else {
				var data = [];
				for (var i = 0; i < 17; i++) {
					data.push(Math.round(100 * Math.random()));
				}
			}


			$(this).sparkline(data, {
				barColor : config.chart.colorPrimary.toString(),
				height : $(this).height(),
				type : type
			});
		});
	}

	drawDashboardItemsListSparklines();

	$(document).on("themechange", function() {
		drawDashboardItemsListSparklines();
	});
});
$(function() {

	var $dashboardSalesBreakdownChart = $('#dashboard-sales-breakdown-chart');

	if (!$dashboardSalesBreakdownChart.length) {
		return false;
	}

	function drawSalesChart() {
		$dashboardSalesBreakdownChart.empty();

		Morris.Donut({
			element : 'dashboard-sales-breakdown-chart',
			data : [ {
				label : "Download Sales",
				value : 12
			},
				{
					label : "In-Store Sales",
					value : 30
				},
				{
					label : "Mail-Order Sales",
					value : 20
				} ],
			resize : true,
			colors : [
				tinycolor(config.chart.colorPrimary.toString()).lighten(10).toString(),
				tinycolor(config.chart.colorPrimary.toString()).darken(8).toString(),
				config.chart.colorPrimary.toString()
			],
		});

		var $sameheightContainer = $dashboardSalesBreakdownChart.closest(".sameheight-container");

		setSameHeights($sameheightContainer);
	}

	drawSalesChart();

	$(document).on("themechange", function() {
		drawSalesChart();
	});

})
$(function() {

	$('.actions-list > li').on('click', '.check', function(e) {
		e.preventDefault();

		$(this).parents('.tasks-item')
			.find('.checkbox')
			.prop("checked", true);

		removeActionList();
	});

});
$(function() {

	if (!$('#dashboard-downloads-chart').length) {
		return false;
	}

	drawDownloadsChart();

	var item = 'downloads';

	$(document).on("themechange", function() {
		switchHistoryCharts(item);
	});

	function switchHistoryCharts(item) {
		var chartSelector = "#dashboard-" + item + "-chart";

		if ($(chartSelector).has('svg').length) {
			$(chartSelector).empty();
		}

		switch (item) {
		case 'downloads':
			drawDownloadsChart();
			break;
		}
	}

	
	function drawDownloadsChart() {
		/*var dataDownloads = [
			{
				year : 'JAN',
				downloads : 1300
			},
			{
				year : 'FEB',
				downloads : 1526
			},
			{
				year : 'MAR',
				downloads : 2000
			},
			{
				year : 'APR',
				downloads : 1800
			},
			{
				year : 'MAY',
				downloads : 1650
			},
			{
				year : 'JUN',
				downloads : 620
			},
			{
				year : 'JUL',
				downloads : 1000
			},
			{
				year : 'AUG',
				downloads : 1896
			},
			{
				year : 'SEP',
				downloads : 850
			},
			{
				year : 'OCT',
				downloads : 1500
			}
		];*/
		 
//
//		Morris.Bar({
//			element : 'dashboard-downloads-chart',
//			data : dataDownloads,
//			xkey : 'year',
//			ykeys : [ 'downloads' ],
//			labels : [ 'Downloads' ],
//			hideHover : 'auto',
//			resize : true,
//			barColors : [
//				config.chart.colorPrimary.toString(),
//				tinycolor(config.chart.colorPrimary.toString()).darken(10).toString()
//			],
//		});
	}
});




var modalMedia = {
	$el : $("#modal-media"),
	result : {},
	options : {},
	open : function(options) {
		options = options || {};
		this.options = options;


		this.$el.modal('show');
	},
	close : function() {
		if ($.isFunction(this.options.beforeClose)) {
			this.options.beforeClose(this.result);
		}

		this.$el.modal('hide');

		if ($.isFunction(this.options.afterClose)) {
			this.options.beforeClose(this.result);
		}
	}
};
$(function() {
	$('.nav-profile > li > a').on('click', function() {
		var $el = $(this).next();

		animate({
			name : 'flipInX',
			selector : $el
		});
	});
})
$(function() {

	// Local storage settings
	var themeSettings = getThemeSettings();

	// Elements

	var $app = $('#app');
	var $styleLink = $('#theme-style');
	var $customizeMenu = $('#customize-menu');

	// Color switcher
	var $customizeMenuColorBtns = $customizeMenu.find('.color-item');

	// Position switchers
	var $customizeMenuRadioBtns = $customizeMenu.find('.radio');


	// /////////////////////////////////////////////////

	// Initial state

	// On setting event, set corresponding options

	// Update customize view based on options

	// Update theme based on options

	/************************************************
	*				Initial State
	*************************************************/

	setThemeSettings();

	/************************************************
	*					Events
	*************************************************/

	// set theme type
	$customizeMenuColorBtns.on('click', function() {
		themeSettings.themeName = $(this).data('theme');

		setThemeSettings();
	});


	$customizeMenuRadioBtns.on('click', function() {

		var optionName = $(this).prop('name');
		var value = $(this).val();

		themeSettings[optionName] = value;

		setThemeSettings();
	});

	function setThemeSettings() {
		setThemeState()
			.delay(config.delayTime)
			.queue(function(next) {

				setThemeColor();
				setThemeControlsState();
				saveThemeSettings();

				$(document).trigger("themechange");

				next();
			});
	}

	/************************************************
	*			Update theme based on options
	*************************************************/

	function setThemeState() {
		// set theme type
		if (themeSettings.themeName) {
			$styleLink.attr('href', 'css/app-' + themeSettings.themeName + '.css');
		} else {
			$styleLink.attr('href', 'css/app.css');
		}

		// App classes
		$app.removeClass('header-fixed footer-fixed sidebar-fixed');

		// set header
		$app.addClass(themeSettings.headerPosition);

		// set footer
		$app.addClass(themeSettings.footerPosition);

		// set footer
		$app.addClass(themeSettings.sidebarPosition);

		return $app;
	}

	/************************************************
	*			Update theme controls based on options
	*************************************************/

	function setThemeControlsState() {
		// set color switcher
		$customizeMenuColorBtns.each(function() {
			if ($(this).data('theme') === themeSettings.themeName) {
				$(this).addClass('active');
			} else {
				$(this).removeClass('active');
			}
		});

		// set radio buttons
		$customizeMenuRadioBtns.each(function() {
			var name = $(this).prop('name');
			var value = $(this).val();

			if (themeSettings[name] === value) {
				$(this).prop("checked", true);
			} else {
				$(this).prop("checked", false);
			}
		});
	}

	/************************************************
	*			Update theme color
	*************************************************/
	function setThemeColor() {
		config.chart.colorPrimary = tinycolor($ref.find(".chart .color-primary").css("color"));
		config.chart.colorSecondary = tinycolor($ref.find(".chart .color-secondary").css("color"));
	}

	/************************************************
	*				Storage Functions
	*************************************************/

	function getThemeSettings() {
		var settings = (localStorage.getItem('themeSettings')) ? JSON.parse(localStorage.getItem('themeSettings')) : {};

		settings.headerPosition = settings.headerPosition || '';
		settings.sidebarPosition = settings.sidebarPosition || '';
		settings.footerPosition = settings.footerPosition || '';

		return settings;
	}

	function saveThemeSettings() {
		localStorage.setItem('themeSettings', JSON.stringify(themeSettings));
	}

});
$(function() {

	$("body").addClass("loaded");

});


/***********************************************
*        NProgress Settings
***********************************************/

// start load bar
NProgress.start();

// end loading bar 
NProgress.done();


/**
 * 
 */

/**
 * chat-bot
 */


$(document).ready(function() {

	var modal = $('#chat-bot-dailog');
	
	$("#disconnect").click(function() {
		// disconnect chat bot once done with conversation
		stompClient.close();
	});
	// invoke connect method while initiating chat bot
	$("#connect").click(function() {
		stompClient.connect();
	//showChart();
	});

	closeChart = function() {
		$('#chart svg').css('display', 'none');
		stompClient.close();
	}

	//nv.addGraph(function() {


	
	//nv.addGraph(function() {
	showChart = function(data) {

		$('#chat-bot-dailog').css('display', 'block');
		// When the user clicks on <span> (x), close the modal
		$('#pop-up-close').click(function() {
			$('#chat-bot-dailog').css('display', 'none');
		});

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == $('#chat-bot-dailog')) {
				$('#chat-bot-dailog').css('display', 'none');
			}
		}

		/*var chart = nv.models.scatterChart()
			.showDistX(true)
			.showDistY(true)
			.xDomain([ 0, 10 ])

			.color(d3.scale.category10().range());

		chart.xAxis.tickFormat(d3.format('.02f'));
		chart.yAxis.tickFormat(d3.format('f'));
		chart.yAxis.ticks(30);
		chart.xAxis.ticks(10);
		
		chart
		      .tooltipContent( function(key, x, y){ 
		          return key;
		      });
		
		chart.yAxis.axisLabel("COST")
		chart.xAxis.axisLabel("Remainng Useful Life Time")
		
		d3.select('#chart svg')
			.datum(data)
			.transition().duration(500)
			.call(chart);
		nv.utils.windowResize(function() {
			chart.update();
			line.attr({
				x1 : 75 + chart.xAxis.scale()(0),
				y1 : 30 + chart.yAxis.scale()(10),
				x2 : 75 + chart.xAxis.scale()(3),
				y2 : 30 + chart.yAxis.scale()(10)
			})

		});*/
		var chart = nv.models.scatterChart()
			.showDistX(true)
			.showDistY(true)

			.color(d3.scale.category10().range());

		chart.xAxis.tickFormat(d3.format('.02f'));
		chart.yAxis.tickFormat(d3.format('f'));
		chart.yAxis.axisLabel("Cost")
		chart.xAxis.axisLabel("RUL")
		d3.select('#chart svg')
			.datum(data)
			.transition().duration(500)
			.call(chart);

		nv.utils.windowResize(chart.update);
	}
	invokeChatAPI("chat-init");

	var i = 1;
	$("#btn-chat").click(function() {
		var query = $('#chat-msg').val();
		//updateResponse("Hi, How I can help you !");
		sendMessage(query);

	});
	$('#chat-msg').keypress(function(event) {
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if (keycode == '13') {
			var query = $('#chat-msg').val();
			//updateResponse("Hi, How I can help you !");
			sendMessage(query);
		}
	});


	function sendMessage(message) {
		i = i + 1;
		//<h7 class="media-heading"><b>Admin</b></h7>
		var time_x = new Date($.now());
		var message_el = '<p> ' + message + ' </p><p style="text-align:right">' + formatAMPM(time_x) + '</p>';
		var chat_con_right_el = '<div class="media right-media" id="chat-conv-r' + i + '"> </div>';
		//alert(chat_con_right_el);
		var chat_head_right_el = '<div class="media-right"><img src="images/user.png" class="media-object" style="width:60px"></div>';
		var msg_body_el = ' <div class="media-body" id="msg-container-r' + i + '"> </div>';
		$("#chat-container").append(chat_con_right_el);
		$("#chat-conv-r" + i).append(msg_body_el);
		//	$("#chat-conv-r" + i).append(chat_head_right_el);
		$("#msg-container-r" + i).append(message_el);
		updateScroll();
		$('#chat-msg').val('');
		invokeChatAPI(message);
	}

	function formatAMPM(date) {
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var ampm = hours >= 12 ? 'pm' : 'am';
		hours = hours % 12;
		hours = hours ? hours : 12; // the hour '0' should be '12'
		minutes = minutes < 10 ? '0' + minutes : minutes;
		var strTime = hours + ':' + minutes + ' ' + ampm;
		return strTime;
	}

	function updateResponse(message) {
		var time_x = new Date($.now());
		//<h4 class="media-heading"><b>Chat Bot</b></h4>
		var message_el = '<p> ' + message + ' </p> <p style="text-align:right">' + formatAMPM(time_x) + '</p>';
		var chat_con_left_el = '<div class="media left-media" id="chat-conv' + i + '"></div>';
		var chat_head_left_el = '<div class="media-left"> <img src="images/bot.png" class="media-object" style="width:60px"></div>';
		var msg_body_el = ' <div class="media-body" id="msg-container' + i + '"></div>';
		$("#chat-container").append(chat_con_left_el);

		//$("#chat-conv" + i).append(chat_head_left_el);
		$("#chat-conv" + i).append(msg_body_el);
		$("#msg-container" + i).append(message_el);
		updateScroll();

	}

	function updateScroll() {
		var scrolled = false;
		if (!scrolled) {
			var element = document.getElementById("chat-container");
			element.scrollTop = element.scrollHeight;
		}
	}

	function invokeChatAPI(query) {
		stompClient.connect();
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "nlp/chatbot/" + query, true);
		xhr.withCredentials = true;
		xhr.setRequestHeader("Authorization", 'Basic ' + btoa('user:user'));
		console.log("abc");
		xhr.onload = function() {
			console.log("loading");
			console.log(xhr.responseText);
			updateResponse(xhr.responseText);

		}
		xhr.send();
	}
	$("#chat-container").on('scroll', function() {
		scrolled = true;
	});
	/**
	 * Chat Bot -- Manage hide and show functionality
	 */
	 $('.chat-bot-icon').fadeIn();
	 $('#chat-bot').hide();
	 $('#main-container').addClass('col-xl-12').removeClass('col-xl-9');
	// showUtilizationChart();
	$("#chat-bot-close").click(function() {
		$('#chat-bot').addClass('col-xl-0').removeClass('col-xl-3');
		$('#chat-bot').hide();
		$("utilization-chart").hide();
		$('#main-container').addClass('col-xl-12').removeClass('col-xl-9');
		$("utilization-chart").show();
		showUtilizationChart();
		$('.chat-bot-icon').fadeIn();

	});
	
	 $('.chat-bot-icon').click(function () {
		 $("utilization-chart").hide();
		 $('#main-container').addClass('col-xl-9').removeClass('col-xl-12');
		 $("utilization-chart").show();
		 showUtilizationChart();
		 $('#chat-bot').show();
		 $('#chat-bot').addClass('col-xl-3').removeClass('col-xl-0');
		 $('.chat-bot-icon').fadeOut();
	    });

	 var   historicalBarChart = [
	        {
	            key: "",
	            values: [
	            	{
	    				year : 'JAN',
	    				downloads : 1300
	    			},
	    			{
	    				year : 'FEB',
	    				downloads : 1526
	    			},
	    			{
	    				year : 'MAR',
	    				downloads : 2000
	    			},
	    			{
	    				year : 'APR',
	    				downloads : 1800
	    			},
	    			{
	    				year : 'MAY',
	    				downloads : 1650
	    			},
	    			{
	    				year : 'JUN',
	    				downloads : 620
	    			},
	    			{
	    				year : 'JUL',
	    				downloads : 1000
	    			},
	    			{
	    				year : 'AUG',
	    				downloads : 1896
	    			},
	    			{
	    				year : 'SEP',
	    				downloads : 850
	    			},
	    			{
	    				year : 'OCT',
	    				downloads : 1500
	    			}
	            ]
	        }
	    ];
	 
	 function showUtilizationChart() {
	        var chart = nv.models.discreteBarChart()
	            .x(function(d) { return d.year })
	            .y(function(d) { return d.downloads })
	            .staggerLabels(true)
	            .staggerLabels(historicalBarChart[0].values.length > 8)
	            .showValues(true)
	            .duration(250)
	            ;

	        d3.select('#utilization-chart svg')
	            .datum(historicalBarChart)
	            .call(chart);

	        nv.utils.windowResize(chart.update);
	       // return chart;
	    
	   }
	
	 showUtilizationChart();
	  
});