/**
 * 
 */

/**
 * chat-bot
 */


$(document).ready(function() {

	var modal = $('#chat-bot-dailog');
	var stompClient = {
			client : null,
			socket : null,
			connect : function() {
				this.socket = new SockJS('/cosmos/websocket');
				this.client = Stomp.over(this.socket);
				//            this.client.debug = null;
				this.client.connect({}, function(frame) {
					stompClient.client.subscribe('/topic/chatbot', function(events) {
						stompClient.consume(events);
					});

					stompClient.client.subscribe('/topic/count', function(events) {
						stompClient.consume(events);
					});
				});
			},
			consume : function(raw) {
				//console.log("Chart DAta   "+raw);
				showChart(JSON.parse(raw.body));

			},
			close : function() {

				if (this.client != null && this.client != undefined) {
					this.client.unsubscribe('/topic/chatbot');
					//	this.client.unsubscribe('/topic/count');
					this.client.disconnect();
					this.client = null;
				}
				closeChart(); // closing chart window
			}
		};

		$("#disconnect").click(function() {
			// disconnect chat bot once done with conversation
			stompClient.close();
		});
		// invoke connect method while initiating chat bot
		$("#connect").click(function() {
			stompClient.connect();
		//showChart();
		});
		
		closeChart = function() {
			$('#chart svg').css('display', 'none');
			stompClient.close();
		}

		stompClient.close();

		//nv.addGraph(function() {
		showChart = function(data) {

			$('#chat-bot-dailog').css('display', 'block');
			// When the user clicks on <span> (x), close the modal
			$('#pop-up-close').click(function() {
				$('#chat-bot-dailog').css('display', 'none');
			});

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target == $('#chat-bot-dailog')) {
					$('#chat-bot-dailog').css('display', 'none');
				}
			}

			var chart = nv.models.scatterChart()
				.showDistX(true)
				.showDistY(true)
				.xDomain([ 0, 10 ])

				.color(d3.scale.category10().range());

			chart.xAxis.tickFormat(d3.format('f'));
			chart.yAxis.tickFormat(d3.format('f'));
			chart.yAxis.ticks(30);
			chart.xAxis.ticks(10);
			
			chart.yAxis.axisLabel("COST")
			chart.xAxis.axisLabel("Remainng Useful Life Time")
			
			d3.select('#chart svg')
				.datum(data)
				.transition().duration(500)
				.call(chart);
			nv.utils.windowResize(function() {
				chart.update();
				line.attr({
					x1 : 75 + chart.xAxis.scale()(0),
					y1 : 30 + chart.yAxis.scale()(10),
					x2 : 75 + chart.xAxis.scale()(3),
					y2 : 30 + chart.yAxis.scale()(10)
				})

			});
		}

		invokeChatAPI("chat-init");
		//stompClient.connect();
		var i = 1;
		$("#btn-chat").click(function() {
			var query = $('#chat-msg').val();
			//updateResponse("Hi, How I can help you !");
			sendMessage(query);

		});
		$('#chat-msg').keypress(function(event) {
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if (keycode == '13') {
				var query = $('#chat-msg').val();
				//updateResponse("Hi, How I can help you !");
				sendMessage(query);
			}
		});


		function sendMessage(message) {
			i = i + 1;
			//<h7 class="media-heading"><b>Admin</b></h7>
			var time_x = new Date($.now());
			var message_el = '<p> ' + message + ' </p><p style="text-align:right">'+formatAMPM(time_x)+'</p>';
			var chat_con_right_el = '<div class="media right-media" id="chat-conv-r' + i + '"> </div>';
			//alert(chat_con_right_el);
			var chat_head_right_el = '<div class="media-right"><img src="images/user.png" class="media-object" style="width:60px"></div>';
			var msg_body_el = ' <div class="media-body" id="msg-container-r' + i + '"> </div>';
			$("#chat-container").append(chat_con_right_el);
			$("#chat-conv-r" + i).append(msg_body_el);
			//	$("#chat-conv-r" + i).append(chat_head_right_el);
			$("#msg-container-r" + i).append(message_el);
			updateScroll();
			$('#chat-msg').val('');
			invokeChatAPI(message);
			stompClient.connect();


		}
		
		function formatAMPM(date) {
			  var hours = date.getHours();
			  var minutes = date.getMinutes();
			  var ampm = hours >= 12 ? 'pm' : 'am';
			  hours = hours % 12;
			  hours = hours ? hours : 12; // the hour '0' should be '12'
			  minutes = minutes < 10 ? '0'+minutes : minutes;
			  var strTime = hours + ':' + minutes + ' ' + ampm;
			  return strTime;
			}

		function updateResponse(message) {
			var time_x = new Date($.now());
			//<h4 class="media-heading"><b>Chat Bot</b></h4>
			var message_el = '<p> ' + message + ' </p> <p style="text-align:right">'+formatAMPM(time_x)+'</p>';
			var chat_con_left_el = '<div class="media left-media" id="chat-conv' + i + '"></div>';
			var chat_head_left_el = '<div class="media-left"> <img src="images/bot.png" class="media-object" style="width:60px"></div>';
			var msg_body_el = ' <div class="media-body" id="msg-container' + i + '"></div>';
			$("#chat-container").append(chat_con_left_el);

			//$("#chat-conv" + i).append(chat_head_left_el);
			$("#chat-conv" + i).append(msg_body_el);
			$("#msg-container" + i).append(message_el);
			updateScroll();

		}

		function updateScroll() {
			var scrolled = false;
			if (!scrolled) {
				var element = document.getElementById("chat-container");
				element.scrollTop = element.scrollHeight;
			}
		}

		function invokeChatAPI(query) {
			//alert("inside fetch")
			var xhr = new XMLHttpRequest();
			xhr.open("GET", "nlp/chatbot/" + query, true);
			xhr.withCredentials = true;
			xhr.setRequestHeader("Authorization", 'Basic ' + btoa('user:user'));
			console.log("abc");
			xhr.onload = function() {
				console.log("loading");
				console.log(xhr.responseText);
				updateResponse(xhr.responseText);

			}
			xhr.send();
		}
		$("#chat-container").on('scroll', function() {
			scrolled = true;
		});

    $("#chatbot-close").click(function(){
        alert("button");
		$('#chatbot-close').hide();
		$('#main-container').addClass('col-xl-12').removeClass('col-xl-8');
		
    }); 
});